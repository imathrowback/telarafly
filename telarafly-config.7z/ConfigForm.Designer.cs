﻿namespace telarafly_config
{
    partial class ConfigForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.assetsDirTextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.assetsDirLocateButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.objectsVisibleTrack = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.terrainVisibleTrack = new System.Windows.Forms.TrackBar();
            this.objectVisValue = new System.Windows.Forms.Label();
            this.terrainVisValue = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.manifestLocateButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.manifestTextbox = new System.Windows.Forms.TextBox();
            this.autoConfigure = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.objectsVisibleTrack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.terrainVisibleTrack)).BeginInit();
            this.SuspendLayout();
            // 
            // assetsDirTextbox
            // 
            this.assetsDirTextbox.Location = new System.Drawing.Point(132, 49);
            this.assetsDirTextbox.Name = "assetsDirTextbox";
            this.assetsDirTextbox.Size = new System.Drawing.Size(293, 20);
            this.assetsDirTextbox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Asset Directory";
            // 
            // assetsDirLocateButton
            // 
            this.assetsDirLocateButton.Location = new System.Drawing.Point(431, 47);
            this.assetsDirLocateButton.Name = "assetsDirLocateButton";
            this.assetsDirLocateButton.Size = new System.Drawing.Size(96, 23);
            this.assetsDirLocateButton.TabIndex = 4;
            this.assetsDirLocateButton.Text = "Locate";
            this.assetsDirLocateButton.UseVisualStyleBackColor = true;
            this.assetsDirLocateButton.Click += new System.EventHandler(this.assetsDirLocateButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Objects Visible";
            // 
            // objectsVisibleTrack
            // 
            this.objectsVisibleTrack.LargeChange = 100;
            this.objectsVisibleTrack.Location = new System.Drawing.Point(91, 99);
            this.objectsVisibleTrack.Maximum = 1000;
            this.objectsVisibleTrack.Minimum = 50;
            this.objectsVisibleTrack.Name = "objectsVisibleTrack";
            this.objectsVisibleTrack.Size = new System.Drawing.Size(381, 45);
            this.objectsVisibleTrack.SmallChange = 10;
            this.objectsVisibleTrack.TabIndex = 7;
            this.objectsVisibleTrack.TickFrequency = 10;
            this.objectsVisibleTrack.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.objectsVisibleTrack.Value = 1000;
            this.objectsVisibleTrack.ValueChanged += new System.EventHandler(this.objectsVisibleTrack_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Terrain Visible";
            // 
            // terrainVisibleTrack
            // 
            this.terrainVisibleTrack.LargeChange = 100;
            this.terrainVisibleTrack.Location = new System.Drawing.Point(93, 150);
            this.terrainVisibleTrack.Maximum = 1000;
            this.terrainVisibleTrack.Minimum = 10;
            this.terrainVisibleTrack.Name = "terrainVisibleTrack";
            this.terrainVisibleTrack.Size = new System.Drawing.Size(379, 45);
            this.terrainVisibleTrack.SmallChange = 10;
            this.terrainVisibleTrack.TabIndex = 9;
            this.terrainVisibleTrack.TickFrequency = 10;
            this.terrainVisibleTrack.Value = 1000;
            this.terrainVisibleTrack.ValueChanged += new System.EventHandler(this.terrainVisibleTrack_ValueChanged);
            // 
            // objectVisValue
            // 
            this.objectVisValue.AutoSize = true;
            this.objectVisValue.Location = new System.Drawing.Point(478, 113);
            this.objectVisValue.Name = "objectVisValue";
            this.objectVisValue.Size = new System.Drawing.Size(35, 13);
            this.objectVisValue.TabIndex = 10;
            this.objectVisValue.Text = "label5";
            // 
            // terrainVisValue
            // 
            this.terrainVisValue.AutoSize = true;
            this.terrainVisValue.Location = new System.Drawing.Point(478, 159);
            this.terrainVisValue.Name = "terrainVisValue";
            this.terrainVisValue.Size = new System.Drawing.Size(35, 13);
            this.terrainVisValue.TabIndex = 11;
            this.terrainVisValue.Text = "label6";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(15, 216);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 12;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(450, 216);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // manifestLocateButton
            // 
            this.manifestLocateButton.Location = new System.Drawing.Point(431, 73);
            this.manifestLocateButton.Name = "manifestLocateButton";
            this.manifestLocateButton.Size = new System.Drawing.Size(96, 23);
            this.manifestLocateButton.TabIndex = 5;
            this.manifestLocateButton.Text = "Locate";
            this.manifestLocateButton.UseVisualStyleBackColor = true;
            this.manifestLocateButton.Click += new System.EventHandler(this.manifestLocateButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Manifest File";
            // 
            // manifestTextbox
            // 
            this.manifestTextbox.Location = new System.Drawing.Point(132, 75);
            this.manifestTextbox.Name = "manifestTextbox";
            this.manifestTextbox.Size = new System.Drawing.Size(293, 20);
            this.manifestTextbox.TabIndex = 3;
            // 
            // autoConfigure
            // 
            this.autoConfigure.Location = new System.Drawing.Point(12, 8);
            this.autoConfigure.Name = "autoConfigure";
            this.autoConfigure.Size = new System.Drawing.Size(130, 23);
            this.autoConfigure.TabIndex = 14;
            this.autoConfigure.Text = "Autoconfigure Paths";
            this.autoConfigure.UseVisualStyleBackColor = true;
            this.autoConfigure.Click += new System.EventHandler(this.autoConfigure_Click);
            // 
            // ConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 251);
            this.Controls.Add(this.autoConfigure);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.terrainVisValue);
            this.Controls.Add(this.objectVisValue);
            this.Controls.Add(this.terrainVisibleTrack);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.objectsVisibleTrack);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.manifestLocateButton);
            this.Controls.Add(this.assetsDirLocateButton);
            this.Controls.Add(this.manifestTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.assetsDirTextbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ConfigForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Telara Config";
            ((System.ComponentModel.ISupportInitialize)(this.objectsVisibleTrack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.terrainVisibleTrack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox assetsDirTextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button assetsDirLocateButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar objectsVisibleTrack;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar terrainVisibleTrack;
        private System.Windows.Forms.Label objectVisValue;
        private System.Windows.Forms.Label terrainVisValue;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button manifestLocateButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox manifestTextbox;
        private System.Windows.Forms.Button autoConfigure;
    }
}

