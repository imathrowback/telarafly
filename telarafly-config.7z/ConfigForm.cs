﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace telarafly_config
{
   
    public partial class ConfigForm : Form
    {
        string configFile = @"telarafly.cfg";
        TelaraConfig config;

        public ConfigForm()
        {
            InitializeComponent();
            bool doAutoConfigure = false;
            config = new TelaraConfig();
            if (File.Exists(configFile))
            {
                DotNet.Config.AppSettings.GlueOnto(config, configFile);
            }
            else
            {
                MessageBox.Show("Unable to find configuration file, using defaults", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                doAutoConfigure = true;
            }

            this.assetsDirTextbox.Text = config.ASSETS_DIR;
            this.manifestTextbox.Text = config.ASSETS_MANIFEST;
            this.objectsVisibleTrack.Value = config.OBJECT_VISIBLE;
            this.terrainVisibleTrack.Value = config.TERRAIN_VIS;

            objectsVisibleTrack_ValueChanged(null, null);
            terrainVisibleTrack_ValueChanged(null, null);

            if (!validate() && doAutoConfigure)
            {
                MessageBox.Show("Attempting auto configuration", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                autoConfigureF();
            }
                
        }

        class InvalidManifestException : Exception
        {
            public InvalidManifestException(string message) : base(message)
            {
            }
        }
        class InvalidAssetDirectoryException : Exception
        {
            public InvalidAssetDirectoryException(string message) : base(message)
            {
            }
        }
        private bool validate()
        {
            return validate(assetsDirTextbox.Text, manifestTextbox.Text);
        }
        private bool validateAssetDir(string assetsDir)
        {
            string firstAssetFile = Path.Combine(assetsDir, "assets.001");
            try
            {
                if (!Directory.Exists(assetsDir))
                    throw new InvalidAssetDirectoryException("it does not point to an existing directory");
                if (isFile(assetsDir))
                    throw new InvalidAssetDirectoryException("it is pointing to a file");
                if (!File.Exists(firstAssetFile))
                    throw new InvalidAssetDirectoryException("we can't find the asset file 'assets.001'");
                if (!checkHeader(firstAssetFile, "TWAD"))
                    throw new InvalidAssetDirectoryException("the asset file 'assets.001' contains an invalid header");
            }
            catch (InvalidAssetDirectoryException ex)
            {
                MessageBox.Show("The asset directory is not valid because " + ex.Message, "Notice", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool validateManifest(string manifestFile)
        {
            try
            {
                if (!File.Exists(manifestFile))
                    throw new InvalidManifestException("it does not point to an existing file");
                if (!isFile(manifestFile))
                    throw new InvalidManifestException("it is pointing to a directory");
                if (!checkHeader(manifestFile, "TWAM"))
                    throw new InvalidManifestException("it does not appear to be a valid manifest file");
            }
            catch (InvalidManifestException ex)
            {
                MessageBox.Show("The manifest file is not valid because " + ex.Message, "Notice", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool validate(string assetsDir, string manifestFile)
        {
            return validateAssetDir(assetsDir) && validateManifest(manifestFile);
        }

        private static bool checkHeader(string file, string headerString)
        {
            byte[] data = File.ReadAllBytes(file);
            byte[] headerBytes = Encoding.ASCII.GetBytes(headerString);
            for (int i = 0; i < headerString.Length; i++)
            {
                if (data[i] != headerBytes[i])
                    return false;
            }
            return true;
        }
        public static bool isDirectory(string dir)
        {
            return ((File.GetAttributes(dir) & FileAttributes.Directory) == FileAttributes.Directory);
        }
        public static bool isFile(string dir)
        {
            return !isDirectory(dir);
        }

        private void objectsVisibleTrack_ValueChanged(object sender, EventArgs e)
        {
            this.objectVisValue.Text = "" + this.objectsVisibleTrack.Value;
        }

        private void terrainVisibleTrack_ValueChanged(object sender, EventArgs e)
        {
            this.terrainVisValue.Text = "" + this.terrainVisibleTrack.Value;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            save();
            MessageBox.Show("Configuration saved");
        }

        private void save()
        { 
            if (!validate())
                return;
            config.ASSETS_DIR = this.assetsDirTextbox.Text;
            config.ASSETS_MANIFEST = this.manifestTextbox.Text;
            config.OBJECT_VISIBLE = this.objectsVisibleTrack.Value;
            config.TERRAIN_VIS = this.terrainVisibleTrack.Value;
            DotNet.Config.AppSettings.saveFrom(config, configFile);
           
        }

        private void assetsDirLocateButton_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                    assetsDirTextbox.Text = fbd.SelectedPath;
            }
        }

        private void manifestLocateButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog fbd = new OpenFileDialog())
            {
                fbd.FileOk += (a, b) =>
                {
                    if (!validateManifest(fbd.FileName))
                        b.Cancel = true;
                };

                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.FileName))
                {
                    manifestTextbox.Text = fbd.FileName;
                }
            }
        }

        private void autoConfigure_Click(object sender, EventArgs e)
        {
            autoConfigureF();
        }

        private void autoConfigureF()
        { 
            // try to read the "riftpatch.cfg" file, it has a line that contains the riftpatchlive.exe
            // that we can use to find RIFT directory.
            try
            {
                string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string path = Path.Combine(appdata, "Rift", "riftpatch.cfg");
                Console.WriteLine("attempt to read :" + path);
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    if (line.StartsWith("CommandLine"))
                    {
                        string name = "riftpatchlive.exe";
                        int eqIndex = line.IndexOf('=') + 1;
                        int index = line.IndexOf(name);
                        string riftPath = line.Substring(eqIndex, index - eqIndex).Replace("\\\\", "\\");

                        string manifest64 = Path.Combine(riftPath, "assets64.manifest");
                        string manifest = Path.Combine(riftPath, "assets.manifest");
                        string assetDir = Path.Combine(riftPath, "assets");
                        string asset = Path.Combine(riftPath, "assets", "assets.001");
                        if (isFile(asset))
                        {
                            Console.Write("found asset:" + asset);
                            if (isFile(manifest64))
                            {
                                Console.WriteLine("found 64 bit manifest:" + manifest64);
                                this.manifestTextbox.Text = manifest64;
                                this.assetsDirTextbox.Text = assetDir;
                            }
                            else if (isFile(manifest))
                            {
                                Console.WriteLine("found manifest:" + manifest);
                                this.manifestTextbox.Text = manifest;
                                this.assetsDirTextbox.Text = assetDir;
                            }
                            else
                                throw new Exception("Can't find manifest files in dir " + riftPath);
                        }
                        else
                            throw new Exception("Can't find asset file " + asset);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                MessageBox.Show("Autoconfiguration failed, please set paths manually\n\n" + ex.Message, "Notice", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void launchButton_Click(object sender, EventArgs e)
        {
            save();
            System.Diagnostics.Process.Start("telarafly.exe");
        }
    }

    class TelaraConfig
    {
        public string ASSETS_DIR = "";
        public string ASSETS_MANIFEST = "";
        public int OBJECT_VISIBLE = 200;
        public int TERRAIN_VIS = 10;
        public int MAX_RUNNING_THREADS = 10;
        public int MAP_LOAD_THREAD_PRIORITY = 4;
        public int OBJECT_LOAD_THREAD_PRIORITY = 4;

    }
}
